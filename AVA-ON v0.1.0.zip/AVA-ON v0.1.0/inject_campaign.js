(function () {

  console.log("INJECT: campaign injector loaded");

  // ===== START 取り逃し救済 =====
  if (window.__campaignStartRequested) {
    console.log("INJECT: START was already requested");
    startAutomation();
  }

  // ===== 元 alert を保存 =====
  const originalAlert = window.alert;

  // ===== 内部状態 =====
  let executed = false;
  let finished = false;
  let running = false;
  let startTime = 0;

  const TIMEOUT = 8000;
  let timer = null;

  // ===== 終了処理（成功・失敗共通） =====
  function finish(reason) {
    if (finished) return;

    finished = true;
    running = false;

    window.alert = originalAlert;
    window.__campaignInjectRunning = false;

    window.postMessage({
      type: "CAMPAIGN_DONE",
      reason
    }, "*");

    if (timer) clearInterval(timer);
  }

  // ===== 成功判定 =====
  function checkSuccess() {
    // 条件1: btn_next_closed.png がある場合
    const imgs = document.getElementsByTagName("img");
    for (const img of imgs) {
      if ((img.src || "").includes("btn_next_closed.png")) {
        finish("success");
        return true;
      }
    }

    // 条件2: i_day_010 クラス内にアイテム画像がある場合
    const dayElems = document.getElementsByClassName("i_day_010");
    for (const elem of dayElems) {
      const dayImgs = elem.getElementsByTagName("img");
      for (const img of dayImgs) {
        if ((img.src || "").match(/\/\/board\.pmang\.jp\/gif\/ava\/mall\/item\/.*\.jpg/)) {
          finish("success");
          return true;
        }
      }
    }

    return false;
  }

  // ===== 自動実行本体 =====
  function startAutomation() {
    if (running) return;

    running = true;
    window.__campaignInjectRunning = true;
    startTime = Date.now();

    // --- alert フック ---
    window.alert = function (msg) {
      console.log("INJECT: alert suppressed:", msg);

      if (
        typeof msg === "string" &&
        msg.includes("ゲームにログインしてください")
      ) {
        finish("not_logged_in");
      }
    };

    // --- ポーリング開始 ---
    timer = setInterval(() => {

      // 成功チェック
      if (checkSuccess()) return;

      // タイムアウト
      if (Date.now() - startTime > TIMEOUT) {
        finish("timeout");
        return;
      }

      // campaign_start 実行
      if (!executed) {
        if (typeof campaign_start === "function") {
          executed = true;
          console.log("INJECT: executing campaign_start");
          try {
            campaign_start("ava");
          } catch (e) {
            finish("exception");
          }
        } else {
          console.log("INJECT: waiting for campaign_start...");
        }
      }

    }, 500);
  }

  // ===== 外部メッセージ受付 =====
  window.addEventListener("message", (event) => {
    if (!event.data) return;

    if (event.data.type === "CAMPAIGN_START") {
      startAutomation();
    }

    if (event.data.type === "CAMPAIGN_STOP") {
      finish("stopped");
    }
  });

})();
