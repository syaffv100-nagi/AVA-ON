// ================================
// AVABOX 1回実行専用（background主導）
// ================================
// play() はページ遷移を引き起こすため、結果検出は
// content script (avaon.js) が shooting ページで行う

/**
 * 1回分の BOX 実行
 */
function playOnce() {
  console.log("INJECT: playOnce start");

  if (typeof play !== "function") {
    console.error("INJECT: play() not found");
    // play() が無い場合のみ通知（ページ遷移しないので）
    window.postMessage({ type: "AUTOBOX_DONE" }, "*");
    return;
  }

  // play() 呼び出し → ページ遷移発生
  // 結果検出は content script (shooting ページ) が担当
  play();
}

/**
 * 開始指示待ち
 */
window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  if (event.data?.type === "START_AUTOBOX_ONCE") {
    console.log("INJECT: START_AUTOBOX_ONCE received");
    playOnce();
  }
});

