// シリアルコード確定用
if (typeof strChk === "function") {
  strChk();
}
