// バックグラウンド処理ソースコード
// Manifest V3 service worker 対応

/* ================================
 * グローバル状態
 * ================================ */
let campaignAccounts = [];
let campaignIndex = 0;
let campaignResults = [];
let campaignRunning = false;
let campaignPageNavigated = false; // ★ アカウント切替・遷移制御用
let remainingPlays = 0;
let autoboxRunning = false;
let autoboxBoxUrl = "";
let autoboxTabId = null;

let itemReceiveAccounts = [];
let itemReceiveIndex = 0;
let itemReceiveUrl = "";
let itemReceiveRunning = false;
let itemReceivePhase = ""; // "navigating_home", "waiting_for_auth", "navigating_target"
let itemReceiveExpectedName = ""; // Expected account name
let itemReceiveTimeout = null;
let itemReceiveResults = [];
let itemReceiveTabId = null;
let itemReceiveGeneration = 0;

let continuousAccounts = [];
let continuousIndex = 0;
let continuousResults = [];
let continuousRunning = false;
let continuousPageNavigated = false;

let refreshAccounts = [];
let refreshIndex = 0;
let refreshRunning = false;
let refreshResults = [];
let refreshOriginalAuth = null;
let refreshTabId = null;

/* ================================
 * 初回インストール処理
 * ================================ */
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(["firstopen"], (items) => {
    if (items.firstopen == null) {
      chrome.storage.sync.set({
        firstopen: "1",
        IDs: ""
      });
    }
  });
});

/* ================================
 * 旧仕様 string メッセージ（getAuth 専用）
 * ================================ */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (typeof request !== "string") return;

  const unPackReq = request.split("&");
  if (unPackReq[0] !== "getAuth") return;

  chrome.cookies.get(
    { url: "https://ava.pmang.jp", name: "GC_AuthInfo" },
    (aCookie) => {
      if (!aCookie) return;

      const response = aCookie.value;
      sendResponse(response);

      if (unPackReq[1] === "#now") return;

      // Hook for Item Receive Auth Verification
      if (itemReceiveRunning && itemReceivePhase === "waiting_for_auth") {
        checkAuthAndProceed(unPackReq[1], sender.tab.id);
        return;
      }

      if (itemReceiveRunning || campaignRunning || continuousRunning) return; // Skip storage write during automated tasks (refresh is excluded: we WANT updates)

      const name = unPackReq[1];
      // Euro情報があれば取得 (形式: getAuth&Name&Euro)
      const euro = unPackReq.length > 2 ? unPackReq[2] : "";

      chrome.storage.sync.get(["IDs"], (items) => {
        if (items.IDs.indexOf(response) === -1) {
          // 新規アカウント追加
          // 形式: Name,Cookie,Euro
          let newLine = name + "," + response;
          if (euro) newLine += "," + euro;

          chrome.storage.sync.set({
            IDs: items.IDs + newLine + "\n"
          });
        } else {
          // 既存アカウント: 名前が変わっていたら更新、かつEuro情報があれば更新
          const lines = items.IDs.trim().split("\n");
          let updated = false;
          const newLines = lines.map(line => {
            const parts = line.split(",");
            // parts[0]: Name, parts[1]: Cookie, parts[2]: Euro (optional)

            if (parts[1] === response) {
              // 名前更新チェック
              if (parts[0] !== name) {
                parts[0] = name;
                updated = true;
              }
              // Euro更新チェック
              if (euro && parts[2] !== euro) {
                parts[2] = euro;
                updated = true;
              } else if (!parts[2] && euro) {
                // 以前は無かったが今回取得できた場合
                parts.push(euro);
                updated = true;
              }
              return parts.join(",");
            }
            return line;
          });

          if (updated) {
            chrome.storage.sync.set({
              IDs: newLines.join("\n") + "\n"
            });
          }
        }
      });
    }
  );

  return true; // async response
});

/* ================================
 * Auth Verification Helper (Item Receive)
 * ================================ */
function checkAuthAndProceed(name, tabId) {
  if (!itemReceiveRunning) return;
  if (itemReceivePhase !== "waiting_for_auth") return;

  const expected = itemReceiveExpectedName;
  console.log(`BG: Auth check. Expected: ${expected}, Got: ${name}`);

  if (name === expected) {
    if (itemReceiveTimeout) clearTimeout(itemReceiveTimeout); // Clear failsafe
    proceedToItemReceive(tabId);
  } else {
    console.log("BG: Auth mismatch, retrying reload...");
    chrome.tabs.reload(tabId);
  }
}

/* ================================
 * メインメッセージハンドラ
 * ================================ */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("BG: message received", request);

  // ===== autobox状態照会 =====
  if (request.type === "IS_AUTOBOX_RUNNING") {
    sendResponse({ running: autoboxRunning });
    return;
  }

  // ===== 開始 =====
  if (request.type === "START_AUTOBOX") {
    remainingPlays = Number(request.count) || 0;
    autoboxRunning = true;
    console.log("BG: AutoBox START", remainingPlays);

    if (remainingPlays > 0) {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        autoboxTabId = tabs[0].id;
        autoboxBoxUrl = tabs[0].url; // box_choice URLを保存
        console.log("BG: AutoBox box URL saved:", autoboxBoxUrl);
        chrome.tabs.sendMessage(tabs[0].id, {
          type: "START_AUTOBOX",
          count: remainingPlays
        });
      });
    }
    return;
  }

  // ===== 1回完了 =====
  if (request.type === "AUTOBOX_DONE") {
    if (!autoboxRunning) return;
    remainingPlays--;
    console.log("BG: AutoBox remaining", remainingPlays);

    if (remainingPlays > 0) {
      // box_choice ページに戻る
      const tabId = autoboxTabId || sender?.tab?.id;
      if (tabId && autoboxBoxUrl) {
        console.log("BG: navigating back to box_choice:", autoboxBoxUrl);
        chrome.tabs.update(tabId, { url: autoboxBoxUrl }, () => {
          // ページロード完了を待ってから次のプレイを指示
          const onComplete = (details) => {
            if (details.tabId === tabId && details.frameId === 0) {
              chrome.webNavigation.onCompleted.removeListener(onComplete);
              // content script の初期化を待つ
              setTimeout(() => {
                if (!autoboxRunning) return;
                console.log("BG: sending next START_AUTOBOX");
                chrome.tabs.sendMessage(tabId, {
                  type: "START_AUTOBOX",
                  count: remainingPlays
                });
              }, 1000);
            }
          };
          chrome.webNavigation.onCompleted.addListener(onComplete);
        });
      }
    } else {
      console.log("BG: AutoBox FINISH");
      autoboxRunning = false;
      const tabId = autoboxTabId || sender?.tab?.id;
      if (tabId) {
        chrome.tabs.sendMessage(tabId, "showboxresult");
      }
      autoboxTabId = null;
      autoboxBoxUrl = "";
    }
    return;
  }

  /* ---------- キャンペーン開始 ---------- */
  if (request === "startCampaign") {
    console.log("BG: startCampaign received");

    campaignRunning = true;
    campaignIndex = 0;
    campaignResults = [];

    chrome.storage.sync.get(["IDs"], (items) => {
      if (!items.IDs || items.IDs.trim() === "") {
        console.log("BG: no accounts");
        return;
      }

      campaignAccounts = items.IDs.trim().split("\n");

      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        if (!tabs[0]) return;

        chrome.tabs.sendMessage(tabs[0].id, { type: "CAMPAIGN_START" }, () => {
          if (chrome.runtime.lastError) {
            console.log("BG: sendMessage skipped (no receiver)");
          }
        });
      });

      switchCampaignAccount();
    });
    return;
  }

  /* ---------- キャンペーン完了 ---------- */
  if (
    campaignRunning &&
    typeof request === "object" &&
    request.type === "CAMPAIGN_DONE"
  ) {
    handleCampaignDone(request);
    return;
  }

  /* ---------- キャンペーン停止 ---------- */
  if (request === "stopCampaign") {
    console.log("BG: stopCampaign received");
    console.log("BG: current results =", campaignResults);

    campaignRunning = false;
    campaignAccounts = [];

    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;

      chrome.tabs.sendMessage(tabs[0].id, { type: "CAMPAIGN_STOP" }, () => {
        if (chrome.runtime.lastError) {
          console.log("BG: sendMessage skipped (no receiver)");
        }
      });

      sendCampaignResult(tabs[0].id, "ログボ受取中断");
    });

    console.log("BG: campaign stopped by user");
    return;
  }

  /* ---------- アイテム受取開始 ---------- */
  if (typeof request === "object" && request.type === "startItemReceive") {
    console.log("BG: startItemReceive received", request.url);

    itemReceiveRunning = true;
    itemReceiveIndex = 0;
    itemReceiveUrl = request.url;
    itemReceiveResults = [];

    chrome.storage.sync.get(["IDs"], (items) => {
      if (!items.IDs || items.IDs.trim() === "") {
        console.log("BG: no accounts");
        return;
      }

      itemReceiveAccounts = items.IDs.trim().split("\n");
      switchItemReceiveAccount();
    });
    return;
  }

  /* ---------- アイテム受取停止 ---------- */
  if (request === "stopItemReceive") {
    console.log("BG: stopItemReceive received");
    const savedResults = itemReceiveResults.slice();
    itemReceiveRunning = false;
    itemReceiveAccounts = [];
    itemReceivePhase = "";
    itemReceiveResults = [];
    if (itemReceiveTimeout) clearTimeout(itemReceiveTimeout);
    detachItemReceiveDebugger();

    // 途中までの結果を表示
    if (savedResults.length > 0) {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        if (!tabs[0]) {
          console.log("BG: stopItemReceive - no active tab found");
          return;
        }
        console.log("BG: sending stop results to tab", tabs[0].id);
        chrome.tabs.sendMessage(tabs[0].id, {
          type: "SHOW_ITEM_RECEIVE_RESULT",
          results: savedResults,
          title: "アイテム受取中断"
        }, (res) => {
          if (chrome.runtime.lastError) {
            console.log("BG: sendMessage failed:", chrome.runtime.lastError.message);
          } else {
            console.log("BG: stop result message response:", res);
          }
        });
      });
    } else {
      console.log("BG: stopItemReceive - no results to show");
    }
    return;
  }

  /* ---------- 連続起動状態照会 ---------- */
  if (request.type === "IS_CONTINUOUS_RUNNING") {
    sendResponse({ running: continuousRunning });
    return;
  }

  /* ---------- 連続起動クリック完了 ---------- */
  if (request.type === "CONTINUOUS_CLICKED") {
    handleContinuousDone(request);
    return;
  }

  /* ---------- 連続起動開始 ---------- */
  if (request === "startContinuous") {
    console.log("BG: startContinuous received");
    continuousRunning = true;
    continuousIndex = 0;
    continuousResults = [];

    chrome.storage.sync.get(["IDs"], (items) => {
      if (!items.IDs || items.IDs.trim() === "") {
        console.log("BG: no accounts");
        continuousRunning = false;
        return;
      }
      continuousAccounts = items.IDs.trim().split("\n");
      switchContinuousAccount();
    });
    return;
  }

  /* ---------- 連続起動停止 ---------- */
  if (request === "stopContinuous") {
    console.log("BG: stopContinuous received");
    continuousRunning = false;
    continuousAccounts = [];


    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      sendContinuousResult(tabs[0].id, "連続起動中断");
    });
    return;
  }

  /* ---------- 全アカウント情報更新 開始 ---------- */
  if (request === "startRefresh") {
    console.log("BG: startRefresh received");
    refreshRunning = true;
    refreshIndex = 0;
    refreshResults = [];

    // 現在のクッキーを保存（完了後に復帰用）
    chrome.cookies.get({ url: "https://ava.pmang.jp", name: "GC_AuthInfo" }, (cookie) => {
      refreshOriginalAuth = cookie ? cookie.value : null;

      chrome.storage.sync.get(["IDs"], (items) => {
        if (!items.IDs || items.IDs.trim() === "") {
          console.log("BG: no accounts for refresh");
          refreshRunning = false;
          return;
        }
        refreshAccounts = items.IDs.trim().split("\n");

        chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
          if (!tabs[0]) { refreshRunning = false; return; }
          refreshTabId = tabs[0].id;
          switchRefreshAccount();
        });
      });
    });
    return;
  }

  /* ---------- 全アカウント情報更新 停止 ---------- */
  if (request === "stopRefresh") {
    console.log("BG: stopRefresh received");
    refreshRunning = false;
    refreshAccounts = [];
    return;
  }

  /* ---------- リフレッシュ中の状態照会 ---------- */
  if (request.type === "IS_REFRESH_RUNNING") {
    sendResponse({ running: refreshRunning });
    return;
  }
});

/* ================================
 * 連続起動時の不要タブ自動クローズ
 * ================================ */
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (continuousRunning && tab.url && tab.url.includes("gameguardfaq.nprotect.com")) {
    console.log("BG: auto closing nProtect tab", tab.url);
    chrome.tabs.remove(tabId).catch(e => console.log("BG: close tab error", e));
  }
});

/* ================================
 * 連続起動アカウント切替処理
 * ================================ */
function switchContinuousAccount() {
  if (!continuousRunning) return;
  if (!continuousAccounts[continuousIndex]) {
    continuousRunning = false;
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (tabs[0]) sendContinuousResult(tabs[0].id, "連続起動完了");
    });
    return;
  }

  continuousPageNavigated = false;
  const value = continuousAccounts[continuousIndex].split(",")[1];
  const accName = continuousAccounts[continuousIndex].split(",")[0];

  console.log(`BG: Continuous Start - Switching to ${accName}`);

  chrome.cookies.set({
    domain: ".pmang.jp",
    url: "https://ava.pmang.jp",
    name: "GC_AuthInfo",
    value: value,
    httpOnly: true
  }, () => {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      chrome.tabs.update(tabs[0].id, { url: "https://ava.pmang.jp/" });
    });
  });
}

function handleContinuousDone(request) {
  if (!continuousRunning) return;

  const accountLine = continuousAccounts[continuousIndex];
  const accountName = accountLine ? accountLine.split(",")[0] : "unknown";

  continuousResults.push({
    index: continuousIndex,
    name: accountName,
    result: "success"
  });

  continuousIndex++;
  switchContinuousAccount();
}

function sendContinuousResult(tabId, title) {
  console.log("BG: sending continuous results", continuousResults);
  // Reuse campaign result UI since it fits well
  chrome.tabs.sendMessage(tabId, {
    type: "SHOW_CAMPAIGN_RESULT",
    results: continuousResults,
    title: title || "連続起動完了"
  }, () => {
    if (chrome.runtime.lastError) {
      console.log("BG: sendMessage skipped (no receiver)");
    }
  });
}

/* ================================
 * アカウント切替処理 (Campaign)
 * ================================ */
function switchCampaignAccount() {
  if (!campaignRunning) return;
  if (!campaignAccounts[campaignIndex]) return;

  campaignPageNavigated = false;

  const value = campaignAccounts[campaignIndex].split(",")[1];

  chrome.cookies.set({
    domain: ".pmang.jp",
    url: "https://ava.pmang.jp",
    name: "GC_AuthInfo",
    value: value,
    httpOnly: true
  }, () => {

    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;

      chrome.tabs.update(tabs[0].id, { url: "https://ava.pmang.jp/" }, () => {
        if (!campaignRunning) return;

        setTimeout(() => {
          if (!campaignRunning) return;
          if (campaignPageNavigated) return;

          campaignPageNavigated = true;
          chrome.tabs.update(tabs[0].id, {
            url: "https://service.pmang.jp/ava/login_campaigns?name=ava"
          });
        }, 1500);
      });
    });
  });
}

/* ================================
 * キャンペーン完了処理
 * ================================ */
function handleCampaignDone(request) {
  if (!campaignRunning) return;

  campaignPageNavigated = true;

  const accountLine = campaignAccounts[campaignIndex];
  const accountName = accountLine ? accountLine.split(",")[0] : "unknown";

  // 結果をオブジェクトとして保存 (avaon.js の overlay 用)
  campaignResults.push({
    index: campaignIndex,
    name: accountName,
    result: request.reason || "unknown"
  });

  campaignIndex++;

  if (campaignIndex < campaignAccounts.length) {
    switchCampaignAccount();
  } else {
    campaignRunning = false;

    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      sendCampaignResult(tabs[0].id, "ログボ自動受取完了");
    });
  }
}

/* ================================
 * 結果送信
 * ================================ */
function sendCampaignResult(tabId, title) {
  console.log("BG: sending campaign results", campaignResults);
  // オブジェクト配列をそのまま送信 (avaon.js で整形表示)
  chrome.tabs.sendMessage(tabId, {
    type: "SHOW_CAMPAIGN_RESULT",
    results: campaignResults,
    title: title || "ログボ自動受取完了"
  }, () => {
    if (chrome.runtime.lastError) {
      console.log("BG: sendMessage skipped (no receiver)");
    }
  });
}

/* ================================
 * 結果文字列変換
 * ================================ */
function getResultText(result) {
  switch (result) {
    case "success": return "成功";
    case "not_logged_in": return "失敗 ゲーム未起動";
    case "popup_detected": return "失敗";
    case "timeout": return "失敗 タイムアウト";
    default: return "不明";
  }
}



/* ================================
 * chrome.debugger: alert ダイアログ自動応答
 * Page.javascriptDialogOpening イベントで alert を検出し、
 * 自動で閉じて次のアカウントへ移行する
 * ================================ */
function attachItemReceiveDebugger(tabId) {
  chrome.debugger.attach({ tabId: tabId }, "1.3", () => {
    if (chrome.runtime.lastError) {
      console.log("BG: debugger attach error:", chrome.runtime.lastError.message);
      return;
    }
    console.log("BG: debugger attached to tab", tabId);
    itemReceiveTabId = tabId;

    chrome.debugger.sendCommand({ tabId: tabId }, "Page.enable", {}, () => {
      if (chrome.runtime.lastError) {
        console.log("BG: Page.enable error:", chrome.runtime.lastError.message);
      } else {
        console.log("BG: Page.enable success");
      }
    });
  });
}

function detachItemReceiveDebugger() {
  if (itemReceiveTabId != null) {
    chrome.debugger.detach({ tabId: itemReceiveTabId }, () => {
      if (chrome.runtime.lastError) {
        console.log("BG: debugger detach error:", chrome.runtime.lastError.message);
      } else {
        console.log("BG: debugger detached");
      }
    });
    itemReceiveTabId = null;
  }
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  if (!itemReceiveRunning) return;
  if (source.tabId !== itemReceiveTabId) return;

  if (method === "Page.javascriptDialogOpening") {
    console.log("BG: alert detected via debugger:", params.message, "type:", params.type);

    const genAtDetect = itemReceiveGeneration;

    // alert を自動で閉じる
    chrome.debugger.sendCommand(
      { tabId: source.tabId },
      "Page.handleJavaScriptDialog",
      { accept: true },
      () => {
        if (chrome.runtime.lastError) {
          console.log("BG: dialog dismiss error:", chrome.runtime.lastError.message);
          return;
        }
        console.log("BG: alert dismissed");

        // 古いアカウントの alert は無視
        if (genAtDetect !== itemReceiveGeneration) {
          console.log("BG: stale alert ignored (gen mismatch)");
          return;
        }

        // 次のアカウントへ
        if (itemReceivePhase === "navigating_target") {
          const accName = itemReceiveAccounts[itemReceiveIndex]?.split(",")[0] || "不明";
          console.log("BG: result recorded:", accName, "received");
          itemReceiveResults.push({ name: accName, result: "received" });
          itemReceivePhase = "done_waiting";
          handleItemReceiveDone();
        }
      }
    );
  }
});

// デバッガがユーザーによって切断された場合
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.tabId === itemReceiveTabId) {
    console.log("BG: debugger detached by user/browser, reason:", reason);
    itemReceiveTabId = null;
  }
});

/* ================================
 * アイテム受取アカウント切替
 * ================================ */
/* ================================
 * アイテム受取: ターゲット遷移
 * ================================ */
function proceedToItemReceive(tabId) {
  if (!itemReceiveRunning) return;

  console.log("BG: Auth verified, proceeding to target");
  itemReceivePhase = "navigating_target";

  const genAtProceed = itemReceiveGeneration;
  chrome.tabs.update(tabId, { url: itemReceiveUrl });

  // Update logic: Timeout for "Already received" or "Success" detection
  if (itemReceiveTimeout) clearTimeout(itemReceiveTimeout);
  itemReceiveTimeout = setTimeout(() => {
    if (itemReceiveRunning && itemReceivePhase === "navigating_target" && genAtProceed === itemReceiveGeneration) {
      const accName = itemReceiveAccounts[itemReceiveIndex]?.split(",")[0] || "不明";
      console.log("BG: item receive timeout, moving to next:", accName);
      itemReceiveResults.push({ name: accName, result: "timeout" });
      itemReceivePhase = "done_waiting";
      handleItemReceiveDone();
    }
  }, 15000);
}

function switchItemReceiveAccount() {
  if (!itemReceiveRunning) return;
  if (!itemReceiveAccounts[itemReceiveIndex]) return;

  console.log(`BG: switching to account ${itemReceiveIndex + 1}/${itemReceiveAccounts.length}`);
  itemReceiveGeneration++;
  itemReceivePhase = "navigating_home";

  const accName = itemReceiveAccounts[itemReceiveIndex].split(",")[0];
  itemReceiveExpectedName = accName;

  const value = itemReceiveAccounts[itemReceiveIndex].split(",")[1];

  chrome.cookies.set({
    domain: ".pmang.jp",
    url: "https://ava.pmang.jp",
    name: "GC_AuthInfo",
    value: value,
    httpOnly: true
  }, () => {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      const tabId = tabs[0].id;

      // 初回のみ debugger をアタッチ
      if (itemReceiveIndex === 0) {
        attachItemReceiveDebugger(tabId);
      } else {
        itemReceiveTabId = tabId;
      }

      // Homeへ遷移して Auth check を待つ
      itemReceivePhase = "waiting_for_auth";
      chrome.tabs.update(tabId, { url: "https://ava.pmang.jp/" });

      // Failsafe timeout for Auth Check (e.g. not logged in)
      if (itemReceiveTimeout) clearTimeout(itemReceiveTimeout);
      itemReceiveTimeout = setTimeout(() => {
        if (itemReceiveRunning && itemReceivePhase === "waiting_for_auth") {
          console.log("BG: Auth wait timeout (not logged in?), skipping:", accName);
          itemReceiveResults.push({ name: accName, result: "not_logged_in" });
          itemReceivePhase = "done_waiting";
          handleItemReceiveDone();
        }
      }, 10000);
    });
  });
}

/* ================================
 * アイテム受取完了処理
 * ================================ */
function handleItemReceiveDone() {
  if (!itemReceiveRunning) return;
  if (itemReceivePhase !== "done_waiting" && itemReceivePhase !== "navigating_target") return;
  itemReceivePhase = "processing";

  if (itemReceiveTimeout) {
    clearTimeout(itemReceiveTimeout);
    itemReceiveTimeout = null;
  }

  itemReceiveIndex++;

  if (itemReceiveIndex < itemReceiveAccounts.length) {
    switchItemReceiveAccount();
  } else {
    console.log("BG: all accounts processed");
    itemReceiveRunning = false;
    itemReceivePhase = "";

    const savedResults = itemReceiveResults.slice();

    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      const tabId = tabs[0].id;

      // Step 1: debugger を切断（切断完了後に次へ進む）
      const afterDetach = () => {
        console.log("BG: debugger detached, navigating to home");

        let resultSent = false;

        const showResult = () => {
          if (resultSent) return;
          resultSent = true;
          chrome.webNavigation.onCompleted.removeListener(onNavCompleted);
          console.log("BG: showing item receive results");

          // Step 3: content script 経由で結果を表示
          chrome.tabs.sendMessage(tabId, { type: "SHOW_ITEM_RECEIVE_RESULT", results: savedResults }, (res) => {
            if (chrome.runtime.lastError) {
              console.log("BG: sendMessage failed:", chrome.runtime.lastError.message);
            } else {
              console.log("BG: result message response:", res);
            }
          });
        };

        const onNavCompleted = (details) => {
          if (details.tabId === tabId && details.frameId === 0 &&
            details.url && details.url.includes("ava.pmang.jp") &&
            !details.url.includes("give_item")) {
            console.log("BG: home page loaded");
            // Step 2.5: content script の初期化を待つ
            setTimeout(showResult, 1500);
          }
        };

        chrome.webNavigation.onCompleted.addListener(onNavCompleted);
        setTimeout(showResult, 15000); // フォールバック

        // Step 2: ホームページに遷移
        chrome.tabs.update(tabId, { url: "https://ava.pmang.jp/" });
      };

      // debugger 切断
      if (itemReceiveTabId != null) {
        const detachTabId = itemReceiveTabId;
        itemReceiveTabId = null;
        chrome.debugger.detach({ tabId: detachTabId }, () => {
          if (chrome.runtime.lastError) {
            console.log("BG: debugger detach error:", chrome.runtime.lastError.message);
          }
          afterDetach();
        });
      } else {
        afterDetach();
      }
    });
  }
}

/* ================================
 * 全アカウント情報更新処理
 * ================================ */
function switchRefreshAccount() {
  if (!refreshRunning) return;

  // 全アカウント処理完了
  if (refreshIndex >= refreshAccounts.length) {
    console.log("BG: refresh all accounts done");
    finishRefresh();
    return;
  }

  const accLine = refreshAccounts[refreshIndex];
  const accName = accLine.split(",")[0];
  const accAuth = accLine.split(",")[1];

  console.log(`BG: Refresh - switching to ${accName} (${refreshIndex + 1}/${refreshAccounts.length})`);

  chrome.cookies.set({
    domain: ".pmang.jp",
    url: "https://ava.pmang.jp",
    name: "GC_AuthInfo",
    value: accAuth,
    httpOnly: true
  }, () => {
    if (!refreshRunning) return;
    chrome.tabs.update(refreshTabId, { url: "https://ava.pmang.jp/" });
  });
}

// AVAトップページ読み込み完了を検知して次のアカウントへ進む
chrome.webNavigation.onCompleted.addListener((details) => {
  if (!refreshRunning) return;
  if (details.tabId !== refreshTabId) return;
  if (details.frameId !== 0) return;
  if (!details.url || !details.url.includes("ava.pmang.jp")) return;

  console.log("BG: refresh - page loaded for account", refreshIndex + 1);

  // content script が getAuth&Name&Euro を送信して storage を更新するのを待つ
  setTimeout(() => {
    if (!refreshRunning) return;

    const accName = refreshAccounts[refreshIndex]?.split(",")[0] || "不明";
    refreshResults.push({ name: accName, result: "success" });

    refreshIndex++;
    switchRefreshAccount();
  }, 3000);
});

function finishRefresh() {
  refreshRunning = false;

  const restoreAndShow = () => {
    // ページ読み込み完了を待って結果を送信
    const onNav = (details) => {
      if (details.tabId !== refreshTabId || details.frameId !== 0) return;
      if (!details.url || !details.url.includes("ava.pmang.jp")) return;
      chrome.webNavigation.onCompleted.removeListener(onNav);

      setTimeout(() => {
        chrome.tabs.sendMessage(refreshTabId, {
          type: "SHOW_REFRESH_RESULT",
          results: refreshResults
        }, () => {
          if (chrome.runtime.lastError) {
            console.log("BG: refresh result send error:", chrome.runtime.lastError.message);
          }
        });
        refreshTabId = null;
      }, 1500);
    };
    chrome.webNavigation.onCompleted.addListener(onNav);
    chrome.tabs.update(refreshTabId, { url: "https://ava.pmang.jp/" });
  };

  // 元のクッキーを復帰
  if (refreshOriginalAuth) {
    chrome.cookies.set({
      domain: ".pmang.jp",
      url: "https://ava.pmang.jp",
      name: "GC_AuthInfo",
      value: refreshOriginalAuth,
      httpOnly: true
    }, () => {
      console.log("BG: refresh - original auth restored");
      restoreAndShow();
    });
  } else {
    restoreAndShow();
  }
}
