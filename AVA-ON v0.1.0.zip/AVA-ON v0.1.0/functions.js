// AVA-ON設定ソースコード
// 2026.02.16-V0.1.0


// 注: ここでいうセッションIDとは "GC_AuthInfo" クッキーのことです

let boxURL;
const ver = "0.1.0";
let selectedAccountIndex = -1;

// ================================
// 共通設定
// ================================

// 右クリック無効
document.oncontextmenu = () => false;

// ================================
// ボタンイベント登録
// ================================

document.getElementById("change").addEventListener("click", acc_change);
document.getElementById("delete").addEventListener("click", acc_delete);
document.getElementById("new").addEventListener("click", acc_new);
document.getElementById("refresh").addEventListener("click", () => {
  if (!confirm("全アカウントの情報をサイトから取得します。\n（処理中はブラウザを操作しないでください）")) return;
  chrome.runtime.sendMessage("startRefresh");
  window.close();
});
document.getElementById("memo").addEventListener("click", editMemo);

document.getElementById("avabox").addEventListener("click", () => {
  openURL("https://ava.pmang.jp/avabox/boxtop");
});

document.getElementById("recieve").addEventListener("click", () => {
  openURL("https://ava.pmang.jp/items/receive");
});

document.getElementById("top").addEventListener("click", () => {
  openURL("https://ava.pmang.jp/");
});

document.getElementById("synthesis").addEventListener("click", () => {
  openURL("https://service.pmang.jp/ava/game_guides/3171");
});

document.getElementById("synthesis_plus").addEventListener("click", () => {
  openURL("https://service.pmang.jp/ava/game_guides/3172");
});

document.getElementById("mixing").addEventListener("click", () => {
  openURL("https://service.pmang.jp/ava/game_guides/3206");
});

document.getElementById("moveUp").addEventListener("click", () => {
  moveAccount(-1);
});

document.getElementById("moveDown").addEventListener("click", () => {
  moveAccount(1);
});

document.getElementById("startContinuous").addEventListener("click", () => {
  chrome.runtime.sendMessage("startContinuous");
  window.close();
});

document.getElementById("stopContinuous").addEventListener("click", () => {
  chrome.runtime.sendMessage("stopContinuous");
});

document.getElementById("startCampaign").addEventListener("click", () => {
  chrome.runtime.sendMessage("startCampaign");
  window.close();
});

document.getElementById("stopCampaign").addEventListener("click", () => {
  chrome.runtime.sendMessage("stopCampaign");
});

document.getElementById("startItemReceive").addEventListener("click", () => {
  const url = window.prompt("アイテム受取URLを入力してください", "");
  if (!url) return;
  chrome.runtime.sendMessage({ type: "startItemReceive", url: url });
  window.close();
});

document.getElementById("stopItemReceive").addEventListener("click", () => {
  chrome.runtime.sendMessage("stopItemReceive");
});

// ================================
// タイトルクリック（コマンドモード）
// ================================

document.getElementsByClassName("titlename")[0].onclick = function () {
  const res = window.prompt("コマンド入力", "");
  if (!res) return;

  const command = res.split(" ");

  switch (command[0]) {
    case "code":
      chrome.tabs.query({ active: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, "code," + command[1]);
        window.close();
      });
      break;

    case "auto":
      const contRow = document.getElementById("continuousRow");
      const isHidden = contRow.style.display === "none";
      contRow.style.display = isHidden ? "" : "none";
      chrome.storage.session.set({ showContinuous: isHidden });
      break;

    case "help":
      alert("'code [シリアルコード]' シリアル入力ページで使うとシリアルが適用されます。");
      break;

    default:
      alert(command[0] + " というコマンドは存在しません");
      break;
  }
};

// ================================
// 共通ユーティリティ
// ================================

function openURL(url) {
  chrome.tabs.query({ active: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.update(tabs[0].id, { url: url });
      window.close();
    }
  });
}

// ================================
// アカウント管理
// ================================

function acc_new() {
  chrome.cookies.remove(
    { url: "https://ava.pmang.jp", name: "GC_AuthInfo" },
    () => {
      chrome.tabs.query({ active: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, "login");
        window.close();
      });
    }
  );
}

function acc_delete() {
  if (selectedAccountIndex === -1) return;

  chrome.storage.sync.get(["IDs"], (items) => {
    const accounts = items.IDs.trim().split("\n");
    if (selectedAccountIndex >= accounts.length) return;
    const pName = accounts[selectedAccountIndex].split(",")[0];

    if (!confirm(`「${pName}」を本当に削除しますか？\n(削除前にAVAページ右上よりログアウトすることをお勧めします)`)) {
      return;
    }

    chrome.cookies.remove(
      { url: "https://ava.pmang.jp", name: "GC_AuthInfo" },
      () => {
        const newIDs = items.IDs
          .replace(accounts[selectedAccountIndex], "")
          .replace("\n\n", "\n");

        chrome.storage.sync.set({ IDs: newIDs.trim() + "\n" }, () => {
          alert("削除しました");
          selectedAccountIndex = -1;
          location.reload(true);
          chrome.tabs.query({ active: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, "reload");
            window.close();
          });
        });
      }
    );
  });
}

function acc_change() {
  if (selectedAccountIndex === -1) return;

  chrome.cookies.remove(
    { url: "https://ava.pmang.jp", name: "GC_AuthInfo" },
    () => {
      chrome.storage.sync.get(["IDs"], (items) => {
        if (!items.IDs) return;
        const accounts = items.IDs.trim().split("\n");
        if (selectedAccountIndex >= accounts.length) return;
        const accdata = accounts[selectedAccountIndex].split(",");
        const authValue = accdata[1];

        chrome.cookies.set(
          {
            domain: ".pmang.jp",
            url: "https://ava.pmang.jp",
            name: "GC_AuthInfo",
            value: authValue,
            httpOnly: true
          },
          () => {
            chrome.tabs.query({ active: true }, (tabs) => {
              chrome.tabs.sendMessage(tabs[0].id, "reload");
              window.close();
            });
          }
        );
      });
    }
  );
}

// ================================
// BOX 自動プレイ
// ================================

function autobox() {
  chrome.tabs.query({ active: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, "getboxremain", (response) => {
      const resArg = response.split("&");
      const playtimes = window.prompt("プレイ回数を入力してください", resArg[1]);

      if (!isNaN(playtimes) && playtimes >= 1) {
        if (confirm(`${resArg[0]}を${playtimes}回実行します\nよろしいですか？`)) {
          autoboxPlay(playtimes);
        }
      }
    });
  });
}

function autoboxPlay(playtimes) {
  document.body.insertAdjacentHTML(
    "beforeend",
    '<div id="fullOverlay"><h1>Processing...</h1>この画面は開いたままにしてください</div>'
  );

  console.log("AUTOBOX start request:", playtimes);
  chrome.runtime.sendMessage({
    type: "START_AUTOBOX",
    count: String(playtimes)
  });
  window.close();
}


// ================================
// 初期ロード処理
// ================================

function w_load() {
  chrome.tabs.query({ active: true }, (tabs) => {
    if (!tabs[0].url.match("https://ava.pmang.jp/*") && !tabs[0].url.match("https://service.pmang.jp/*")) {
      let avabtn = '<br><button class="btn btn-primary" id="openAVAHP">🚀 AVA公式サイトへ</button>';

      document.body.insertAdjacentHTML(
        "beforeend",
        `<div id="fullOverlay"><h1>AVA-ON</h1>AVA公式サイト以外では動作しません${avabtn}</div>`
      );

      document.getElementById("openAVAHP").addEventListener("click", () => {
        openURL("https://ava.pmang.jp/");
      });
    }
  });

  // autoコマンドの表示状態を復元
  chrome.storage.session.get(["showContinuous"], (result) => {
    if (result.showContinuous) {
      document.getElementById("continuousRow").style.display = "";
    }
  });

  loadAccountList();

  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    const str = String(tabs[0].url).split("?")[0];
    if (str === "https://ava.pmang.jp/avabox/box_choice") {
      boxURL = String(tabs[0].url);
      document.getElementById("autoboxRow").style.display = "";
      document.getElementById("autobox").addEventListener("click", (e) => {
        e.preventDefault();
        autobox();
      });
    }
  });

  const xhr = new XMLHttpRequest();
  xhr.responseType = "document";
  xhr.onload = (e) => {
    const dom = e.target.responseXML;
    const articles = dom.getElementsByClassName("ttl");

    let eventname;
    let eventurl;

    for (const el of articles) {
      if (String(el.innerHTML).includes("今週のイベント開催情報")) {
        eventname = el.getElementsByTagName("a")[0].innerHTML;
        eventurl = el.getElementsByTagName("a")[0].getAttribute("href"); // getAttributeを使う方が安全
        if (eventurl && !eventurl.startsWith("http")) {
          eventurl = "https://ava.pmang.jp" + eventurl;
        }
        break;
      }
    }

    if (eventname) {
      document.getElementsByClassName("event")[0].innerHTML = `<a href="#" class="eventOpen">${eventname}</a>`;
      document.getElementsByClassName("eventOpen")[0].addEventListener("click", (e) => {
        e.preventDefault();
        openURL(eventurl);
      });
    } else {
      document.getElementsByClassName("event")[0].innerHTML = "イベント情報の取得に失敗しました";
    }
  };
  xhr.open("get", "https://ava.pmang.jp/");
  xhr.send();
}

function loadAccountList() {
  const container = document.getElementById("account-list-container");
  container.innerHTML = "";

  chrome.storage.sync.get(["IDs"], (items) => {
    chrome.runtime.sendMessage("getAuth&#now", (response) => {
      if (!items.IDs) return;
      const accounts = items.IDs.split("\n");

      let totalEuro = 0;
      let hasEuroData = false;

      accounts.forEach((element, i) => {
        const accdata = element.split(",");
        if (!accdata[0]) return;

        const isActive = response === accdata[1];
        let displayText = `${i + 1}. ${accdata[0]}`;

        // Euro情報があれば表示
        if (accdata.length > 2 && accdata[2]) {
          const euroNum = Number(accdata[2]);
          const euroStr = isNaN(euroNum) ? accdata[2] : euroNum.toLocaleString();
          displayText += ` (${euroStr}€)`;
          if (!isNaN(euroNum)) {
            totalEuro += euroNum;
            hasEuroData = true;
          }
        }

        // メモがあれば📝アイコンを追加
        const memo = (accdata.length > 3) ? accdata.slice(3).join(",") : "";
        if (memo) {
          displayText += ' <span class="memo-icon">📝</span>';
        }

        const div = document.createElement("div");
        div.className = "account-item" + (isActive ? " active-account" : "");
        div.dataset.index = i;
        div.dataset.memo = memo;
        div.innerHTML = displayText;

        // クリックで選択
        div.addEventListener("click", () => {
          container.querySelectorAll(".account-item").forEach(el => el.classList.remove("selected"));
          div.classList.add("selected");
          selectedAccountIndex = i;
        });

        // ホバーでメモ表示
        if (memo) {
          div.addEventListener("mouseenter", (e) => showMemo(e, memo));
          div.addEventListener("mousemove", (e) => moveMemo(e));
          div.addEventListener("mouseleave", () => hideMemo());
        }

        container.appendChild(div);
      });

      // 合計ユーロを表示
      const totalEuroEl = document.getElementById("total-euro");
      if (totalEuroEl && hasEuroData) {
        totalEuroEl.textContent = `💰 ${totalEuro.toLocaleString()}€`;
      }

      // 前回の選択状態を復元
      chrome.storage.sync.get(["lastSelectedIndex"], (sel) => {
        if (
          typeof sel.lastSelectedIndex === "number" &&
          sel.lastSelectedIndex >= 0
        ) {
          const items = container.querySelectorAll(".account-item");
          if (sel.lastSelectedIndex < items.length) {
            items[sel.lastSelectedIndex].classList.add("selected");
            selectedAccountIndex = sel.lastSelectedIndex;
          }
          chrome.storage.sync.remove("lastSelectedIndex");
        }
      });
    });
  });
}

// ================================
// メモ機能
// ================================

function showMemo(e, memo) {
  const tooltip = document.getElementById("memo-tooltip");
  tooltip.textContent = memo;
  tooltip.style.display = "block";
  positionTooltip(tooltip, e);
}

function moveMemo(e) {
  const tooltip = document.getElementById("memo-tooltip");
  positionTooltip(tooltip, e);
}

function hideMemo() {
  const tooltip = document.getElementById("memo-tooltip");
  tooltip.style.display = "none";
}

function positionTooltip(tooltip, e) {
  let x = e.clientX + 12;
  let y = e.clientY + 12;
  // 画面外にはみ出ないよう調整
  const rect = tooltip.getBoundingClientRect();
  if (x + rect.width > window.innerWidth) {
    x = e.clientX - rect.width - 8;
  }
  if (y + rect.height > window.innerHeight) {
    y = e.clientY - rect.height - 8;
  }
  tooltip.style.left = x + "px";
  tooltip.style.top = y + "px";
}

function editMemo() {
  if (selectedAccountIndex === -1) {
    alert("メモを編集するアカウントを選択してください");
    return;
  }

  chrome.storage.sync.get(["IDs"], (items) => {
    if (!items.IDs) return;
    const accounts = items.IDs.trim().split("\n");
    if (selectedAccountIndex >= accounts.length) return;

    const accdata = accounts[selectedAccountIndex].split(",");
    const currentMemo = (accdata.length > 3) ? accdata.slice(3).join(",") : "";

    const newMemo = window.prompt(
      `「${accdata[0]}」のメモを入力してください\n（空欄で削除）`,
      currentMemo
    );

    if (newMemo === null) return; // キャンセル

    // メモにカンマが含まれていてもOK（最後のフィールドとしてslice(3).join(",")で復元）
    // ただし改行はスペースに置換
    const sanitizedMemo = newMemo.replace(/\n/g, " ").trim();

    // アカウントデータを再構築（name, auth, euro, memo）
    const name = accdata[0] || "";
    const auth = accdata[1] || "";
    const euro = accdata[2] || "";
    accounts[selectedAccountIndex] = sanitizedMemo
      ? `${name},${auth},${euro},${sanitizedMemo}`
      : `${name},${auth},${euro}`;

    chrome.storage.sync.set(
      {
        IDs: accounts.join("\n") + "\n",
        lastSelectedIndex: selectedAccountIndex
      },
      () => location.reload()
    );
  });
}

function sleep(waitMsec) {
  const startMsec = new Date();
  while (new Date() - startMsec < waitMsec);
}

function moveAccount(direction) {
  if (selectedAccountIndex === -1) return;

  const index = selectedAccountIndex;

  chrome.storage.sync.get(["IDs"], (items) => {
    const accounts = items.IDs.trim().split("\n");
    const target = index + direction;

    if (target < 0 || target >= accounts.length) return;

    [accounts[index], accounts[target]] = [accounts[target], accounts[index]];

    chrome.storage.sync.set(
      {
        IDs: accounts.join("\n") + "\n",
        lastSelectedIndex: target
      },
      () => location.reload()
    );
  });
}

// ================================
// 起動時
// ================================

w_load();
