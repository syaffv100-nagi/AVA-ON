//AVA-ON メインソースコード
// 2026.02.16-V0.1.0


// ================= アイテム受取: alert フック (document_start) =================
// ログボ自動受取(inject_campaign.js)と同じ方式:
// content script が document_start で実行 → inline <script> で MAIN world の
// window.alert を差し替える（manifest 静的登録のバックアップ）
if (location.href.match(/ava\.pmang\.jp\/give_item\//)) {
  var _s = document.createElement("script");
  _s.textContent = 'if(!window.__itemReceiveAlertMsg){window.__itemReceiveAlertMsg=null;window.alert=function(msg){console.log("INJECT: item receive alert suppressed:",msg);window.__itemReceiveAlertMsg=String(msg);window.postMessage({type:"ITEM_RECEIVE_ALERT",message:String(msg)},"*");};}';
  (document.documentElement || document).appendChild(_s);
  _s.remove();
  console.log("CONTENT: item receive alert hook injected inline");
  // 診断: content script がこのページで動作していることを background に通知
  try { chrome.runtime.sendMessage({ type: "ITEM_RECEIVE_PAGE_LOADED", url: location.href }); } catch (e) { }
}

// ================= グローバル =================
var nowURL = null;

// ================= AUTOBOX: shooting ページ自動結果検出 =================
if (location.href.includes("ava.pmang.jp/avabox/shooting")) {
  document.addEventListener('DOMContentLoaded', function () {
    chrome.runtime.sendMessage({ type: "IS_AUTOBOX_RUNNING" }, (response) => {
      if (!response || !response.running) return;
      console.log("CONTENT: shooting page detected during autobox");

      let done = false;
      const timer = setInterval(() => {
        if (done) return;
        const resultArea = document.getElementById("result_area");
        const itemName = document.querySelector("#item_name p");
        if (resultArea && itemName) {
          done = true;
          clearInterval(timer);
          console.log("CONTENT: BOX result detected:", itemName.textContent);

          // closeResult() を MAIN world で実行
          const s = document.createElement("script");
          s.textContent = 'if(typeof closeResult==="function"){closeResult();}';
          (document.head || document.documentElement).appendChild(s);
          s.remove();

          // アニメーション後に background に通知
          setTimeout(() => {
            chrome.runtime.sendMessage({ type: "AUTOBOX_DONE" });
          }, 1000);
        }
      }, 300);

      // タイムアウト: 30秒で強制完了
      setTimeout(() => {
        if (!done) {
          done = true;
          clearInterval(timer);
          console.log("CONTENT: shooting page result timeout, forcing AUTOBOX_DONE");
          chrome.runtime.sendMessage({ type: "AUTOBOX_DONE" });
        }
      }, 30000);
    });
  });
}

// ================= DOM 読み込み完了 =================
document.addEventListener('DOMContentLoaded', function () {
  console.log("AVAON DOMContentLoaded");

  nowURL = window.location;
  var pName = null;

  try {
    // 左サイドのプレーヤー情報からプレーヤー名を取得
    var elements = document.getElementsByClassName("user-information");
    pName = elements[0]
      .innerHTML
      .split("</p>")[0]
      .replace("<p>", "")
      .trim();

    document.getElementsByClassName("btn_logout")[0].innerHTML =
      '<div style="color:white">AVA-ON起動中</div>';

    console.log("Player detected:", pName);
  } catch (error) {
    console.log("Player name not found", error);
  }

  if (pName) {
    // ユーロ情報の取得
    var euro = "unknown";
    try {
      var dl = elements[0].getElementsByTagName("dl")[0];
      var dts = dl.getElementsByTagName("dt");
      var dds = dl.getElementsByTagName("dd");

      for (var i = 0; i < dts.length; i++) {
        if (dts[i].textContent.includes("Euro")) {
          euro = dds[i].textContent.trim();
          break;
        }
      }
      console.log("Euro detected:", euro);
    } catch (e) {
      console.log("Euro parse error", e);
    }

    // セッションID取得要求 + Euro更新
    // 既存の "getAuth&" メッセージはそのまま維持しつつ、
    // 新しい形式のメッセージも送るか、既存を拡張するか。
    // ここでは互換性のため "getAuth" はそのままで、追加で "UPDATE_EURO" を送る形にする
    // あるいは "getAuth" のレスポンスで保存処理をしているので、
    // background 側で "getAuth" メッセージに Euro 情報を含めるように変更する

    // 変更: getAuthメッセージにEuro情報を含めて送信
    // 形式: getAuth&AccountName&EuroAmount
    chrome.runtime.sendMessage("getAuth&" + pName + "&" + euro, function (response) {
      console.log("getAuth response:", response);
    });
  }

  // ==== 連続起動の自動クリック処理 ====
  if (location.href === "https://ava.pmang.jp/" || location.href === "https://ava.pmang.jp") {
    // リフレッシュ中は連続起動の自動クリックをスキップ
    chrome.runtime.sendMessage({ type: "IS_REFRESH_RUNNING" }, (rr) => {
      if (rr && rr.running) return;
      chrome.runtime.sendMessage({ type: "IS_CONTINUOUS_RUNNING" }, (res) => {
        if (res && res.running) {
          console.log("CONTENT: Continuous Start is running. Waiting for Game Start button...");
          setTimeout(() => {
            const btn = document.querySelector('.login_gamestart a.imgsp');
            if (btn) {
              console.log("CONTENT: Found Game Start button. Clicking...");
              btn.click();
              // クリックによりページが /gamestart へ遷移するため、以降の待機処理はそちらで行う
            } else {
              console.log("CONTENT: Game Start button NOT found. Proceeding to next account.");
              chrome.runtime.sendMessage({ type: "CONTINUOUS_CLICKED" });
            }
          }, 2000); // ページのロード完了後、念のため2秒待つ
        }
      });
    });
  }

  // ==== 連続起動の待機＆次アカウント進行処理（gamestartページ） ====
  if (location.href.includes("ava.pmang.jp/gamestart")) {
    chrome.runtime.sendMessage({ type: "IS_CONTINUOUS_RUNNING" }, (res) => {
      if (res && res.running) {
        console.log("CONTENT: gamestart page detected. Waiting 5 seconds before proceeding.");
        setTimeout(() => {
          chrome.runtime.sendMessage({ type: "CONTINUOUS_CLICKED" });
        }, 5000);
      }
    });
  }
});

// ================= runtime メッセージ（旧来文字列系） =================
chrome.runtime.onMessage.addListener(function (req, sender, sendResponse) {
  var request;
  var arr;

  if (typeof req === "string" && req.indexOf(",") !== -1) {
    const _req = req.split(",");
    request = _req[0];
    arr = _req[1];
  } else {
    request = req;
  }

  console.log("runtime message received:", request);

  if (request === "reload") {
    window.location.reload(true);

  } else if (request === "login") {
    window.location.href = "https://api.pmang.jp/login/relogin?service=ava&pageurl=https://ava.pmang.jp/";

  } else if (request === "getboxremain") {
    sendResponse(getboxremain());

  } else if (request === "playbox") {
    console.log("playbox requested");
    var s = document.createElement("script");
    s.src = chrome.runtime.getURL("inject_play.js");
    s.onload = () => s.remove();
    (document.head || document.documentElement).appendChild(s);

  } else if (request === "isLoaded") {
    sendResponse(nowURL);

  } else if (request === "showboxresult") {
    window.location.href = "https://ava.pmang.jp/avabox/history";

  } else if (request === "code") {
    console.log("code input:", arr);
    document.getElementsByName("code1")[0].value = arr.substr(0, 4);
    document.getElementsByName("code2")[0].value = arr.substr(4, 4);
    document.getElementsByName("code3")[0].value = arr.substr(8, 4);

    var s2 = document.createElement("script");
    s2.src = chrome.runtime.getURL("inject_strChk.js");
    s2.onload = () => s2.remove();
    (document.head || document.documentElement).appendChild(s2);

  } else if (typeof request === "string") {
    window.location.href = request;
  }
});

// ================= BOX 残り回数取得 =================
function getboxremain() {
  var response_n = 5;
  const remain_element = document.getElementsByClassName("txt_ygreen");

  if (remain_element.length === 2) {
    try {
      response_n = remain_element[1]
        .innerHTML
        .split("あと<strong>")[1]
        .split("</strong>")[0];
    } catch (error) {
      console.log("getboxremain parse error", error);
    }
  }

  const boxname = remain_element[0]
    .innerHTML
    .split("<strong>")[1]
    .split("</strong>")[0];

  console.log("box remain:", boxname, response_n);
  return boxname + "&" + response_n;
}

// ================= Campaign inject =================
if (
  location.href.startsWith("https://service.pmang.jp/ava/login_campaigns") &&
  !window.__campaignInjectLoaded
) {
  window.__campaignInjectLoaded = true;
  console.log("Campaign page detected, injecting script");

  window.postMessage({ type: "CAMPAIGN_START" }, "*");

  const s = document.createElement("script");
  s.src = chrome.runtime.getURL("inject_campaign.js");
  s.onload = () => {
    console.log("inject_campaign loaded");
    window.postMessage({ type: "CAMPAIGN_START" }, "*");
    s.remove();
  };
  (document.head || document.documentElement).appendChild(s);
}

if (document.querySelector('img[src*="btn_next_closed"]')) {
  console.log("CS: already completed");
}

// ================= inject → background 橋渡し =================
window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  if (event.data && event.data.type === "CAMPAIGN_DONE") {
    console.log("CONTENT: CAMPAIGN_DONE received", event.data.reason);

    window.__campaignFinished = true;

    chrome.runtime.sendMessage({
      type: "CAMPAIGN_DONE",
      reason: event.data.reason
    });
  }
});

// ================= background → inject =================
chrome.runtime.onMessage.addListener((request) => {
  if (request.type === "CAMPAIGN_START") {
    if (window.__campaignFinished) {
      console.log("CONTENT: campaign already finished, ignore START");
      return;
    }

    console.log("CONTENT: forwarding CAMPAIGN_START to inject");
    window.__campaignStartRequested = true;

    window.postMessage({ type: "CAMPAIGN_START" }, "*");
  }

  if (request.type === "CAMPAIGN_STOP") {
    console.log("CONTENT: forwarding CAMPAIGN_STOP to inject");
    window.postMessage({ type: "CAMPAIGN_STOP" }, "*");
  }
});

// ================= 共通オーバーレイ表示 =================
function createResultOverlay(headerTitle, results, formatResult) {
  // Style injection (animation keyframes)
  if (!document.getElementById("__avaon_overlay_style")) {
    const styleEl = document.createElement("style");
    styleEl.id = "__avaon_overlay_style";
    styleEl.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&family=Orbitron:wght@600;700&display=swap');
      @keyframes __avaon_fadeIn { from { opacity:0; transform:scale(0.95) translateY(10px); } to { opacity:1; transform:scale(1) translateY(0); } }
      @keyframes __avaon_overlayIn { from { opacity:0; } to { opacity:1; } }
    `;
    (document.head || document.documentElement).appendChild(styleEl);
  }

  // Overlay background
  const overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(13,13,26,0.92); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); z-index:999999; display:flex; justify-content:center; align-items:center; animation:__avaon_overlayIn 0.3s ease;";

  // Content card
  const content = document.createElement("div");
  content.style.cssText = "background:rgba(26,26,46,0.95); border:1px solid rgba(0,229,255,0.25); border-radius:10px; padding:28px 32px; max-width:420px; width:90%; max-height:80vh; overflow-y:auto; box-shadow:0 8px 32px rgba(0,0,0,0.4), 0 0 20px rgba(0,229,255,0.1); animation:__avaon_fadeIn 0.4s ease 0.1s both;";

  // Title with gradient
  const title = document.createElement("h3");
  title.textContent = headerTitle;
  title.style.cssText = "margin:0 0 16px 0; padding-bottom:12px; border-bottom:1px solid rgba(0,229,255,0.2); font-family:'Orbitron',sans-serif; font-size:16px; font-weight:700; background:linear-gradient(135deg,#00e5ff,#7c4dff); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; letter-spacing:0.5px;";

  // Result list
  const list = document.createElement("div");
  list.style.cssText = "font-family:'Noto Sans JP',sans-serif; font-size:13px; line-height:1.8;";

  if (results && results.length > 0) {
    results.forEach((r, i) => {
      const row = document.createElement("div");
      row.style.cssText = "display:flex; align-items:center; padding:6px 10px; border-radius:6px; margin-bottom:4px; background:rgba(255,255,255,0.03); transition:background 0.2s;";
      row.onmouseenter = () => { row.style.background = "rgba(0,229,255,0.08)"; };
      row.onmouseleave = () => { row.style.background = "rgba(255,255,255,0.03)"; };

      const num = document.createElement("span");
      num.textContent = `${i + 1}.`;
      num.style.cssText = "color:#606080; font-size:12px; min-width:24px; font-family:'Orbitron',sans-serif;";

      const name = document.createElement("span");
      name.textContent = r.name;
      name.style.cssText = "color:#e8e8f0; flex:1; margin:0 8px;";

      const status = document.createElement("span");
      const { text, color } = formatResult(r);
      status.textContent = text;
      status.style.cssText = `color:${color}; font-size:12px; font-weight:500; white-space:nowrap;`;

      row.appendChild(num);
      row.appendChild(name);
      row.appendChild(status);
      list.appendChild(row);
    });
  }

  // Close button
  const closeBtn = document.createElement("button");
  closeBtn.textContent = "✕ 閉じる";
  closeBtn.style.cssText = "display:block; width:100%; margin-top:20px; padding:10px; background:transparent; color:#00e5ff; border:1px solid rgba(0,229,255,0.4); border-radius:6px; font-family:'Noto Sans JP',sans-serif; font-size:13px; font-weight:500; cursor:pointer; transition:all 0.2s; letter-spacing:1px;";
  closeBtn.onmouseenter = () => { closeBtn.style.background = "rgba(0,229,255,0.15)"; closeBtn.style.borderColor = "#00e5ff"; closeBtn.style.boxShadow = "0 0 12px rgba(0,229,255,0.3)"; };
  closeBtn.onmouseleave = () => { closeBtn.style.background = "transparent"; closeBtn.style.borderColor = "rgba(0,229,255,0.4)"; closeBtn.style.boxShadow = "none"; };
  closeBtn.onclick = () => overlay.remove();

  content.appendChild(title);
  content.appendChild(list);
  content.appendChild(closeBtn);
  overlay.appendChild(content);

  // Click overlay background to close
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

  const target = document.body || document.documentElement;
  if (target) {
    target.appendChild(overlay);
  } else {
    console.error("createResultOverlay: No body/documentElement to append overlay to");
  }
}

// ================= 結果表示 =================
chrome.runtime.onMessage.addListener((request) => {
  if (request.type === "SHOW_CAMPAIGN_RESULT") {
    console.log("SHOW_CAMPAIGN_RESULT received");

    const headerTitle = request.title || "ログボ自動受取完了";
    createResultOverlay(headerTitle, request.results, (r) => {
      switch (r.result) {
        case "success": return { text: "✅ 成功", color: "#00e676" };
        case "not_logged_in": return { text: "❌ 失敗(未ログイン)", color: "#ff3d5a" };
        case "popup_detected": return { text: "❌ 失敗(ポップアップ)", color: "#ff3d5a" };
        case "timeout": return { text: "⚠ タイムアウト", color: "#ffab40" };
        default: return { text: r.result || "不明", color: "#9090b0" };
      }
    });
  }
});

chrome.runtime.onMessage.addListener((request) => {
  if (request.type === "START_AUTOBOX") {
    console.log("CONTENT: START_AUTOBOX received", request.count);

    // 初回: inject_play.js をロード、2回目以降: ロード済みなのでメッセージのみ
    if (!window.__injectPlayLoaded) {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("inject_play.js");
      s.onload = () => {
        console.log("inject_play loaded for autobox");
        window.__injectPlayLoaded = true;
        s.remove();
        // ロード完了後に最初の1回を指示
        window.postMessage({ type: "START_AUTOBOX_ONCE" }, "*");
      };
      (document.head || document.documentElement).appendChild(s);
    } else {
      // 既にロード済み → メッセージだけ
      window.postMessage({ type: "START_AUTOBOX_ONCE" }, "*");
    }
  }
});

// ================= inject → background 橋渡し =================
window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  if (event.data?.type === "AUTOBOX_DONE") {
    console.log("CONTENT: AUTOBOX_DONE received");

    chrome.runtime.sendMessage({
      type: "AUTOBOX_DONE"
    });
  }
});

// ================= background → inject =================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "START_AUTOBOX_ONCE") {
    console.log("CONTENT: START_AUTOBOX_ONCE");

    // ★ inject はしない。通知だけ
    window.postMessage({ type: "START_AUTOBOX_ONCE" }, "*");
  }
});

// ================= アイテム受取: inject → background 橋渡し =================
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.data?.type === "ITEM_RECEIVE_ALERT") {
    console.log("CONTENT: ITEM_RECEIVE_ALERT received", event.data.message);
    chrome.runtime.sendMessage({ type: "ITEM_RECEIVE_DONE" });
  }
});

// ================= アイテム受取完了表示 =================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "SHOW_ITEM_RECEIVE_RESULT") {
    console.log("SHOW_ITEM_RECEIVE_RESULT received");
    const headerTitle = request.title || "アイテム受取完了";
    // sendResponse を先に呼ぶ
    sendResponse("ok");

    createResultOverlay(headerTitle, request.results, (r) => {
      if (r.result === "timeout" || r.result === "not_logged_in") return { text: "⚠ タイムアウト", color: "#ff3d5a" };
      return { text: "✅ 受取済み", color: "#00e676" };
    });
  }
});

// ================= 全アカウント情報更新 結果表示 =================
chrome.runtime.onMessage.addListener((request) => {
  if (request.type === "SHOW_REFRESH_RESULT") {
    console.log("SHOW_REFRESH_RESULT received");
    createResultOverlay("全アカウント情報更新完了", request.results, (r) => {
      if (r.result === "success") return { text: "✅ 更新済み", color: "#00e676" };
      return { text: "⚠ 不明", color: "#ffab40" };
    });
  }
});
