// アイテム受取モード: MAIN world で alert() を差し替え
// ページスクリプトより先に実行される
(function () {
    window.__itemReceiveAlertMsg = null;
    window.alert = function (msg) {
        console.log("INJECT: item receive alert suppressed:", msg);
        window.__itemReceiveAlertMsg = String(msg);
        window.postMessage({ type: "ITEM_RECEIVE_ALERT", message: String(msg) }, "*");
    };
})();
